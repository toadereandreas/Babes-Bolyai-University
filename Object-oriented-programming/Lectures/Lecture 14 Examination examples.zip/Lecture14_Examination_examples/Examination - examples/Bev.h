#pragma once
#include <string>

class Beverage
{
private:
	std::string description;

public:
	Bev(const std::string& desc);
	~Bev();
	virtual double price() = 0;
	virtual void print()
	{
		std::cout << this->description << this->price() << std::endl;
	}
};

class BeverageWithMilk : public Beverage
{

};
