#pragma once

#include <QWidget>
#include "ui_ShoppingBasketGUI.h"
#include "Controller.h"
#include "Observer.h"

class ShoppingBasketGUI : public QWidget, public Observer
{
	Q_OBJECT

private:
	Controller& ctrl;

public:
	ShoppingBasketGUI(Controller& c, QWidget *parent = Q_NULLPTR);
	~ShoppingBasketGUI();

	void update() override;

private:
	Ui::ShoppingBasketGUI ui;

	void populateList();
};
