#include "ShoppingBasketGUI.h"

ShoppingBasketGUI::ShoppingBasketGUI(Controller& c, QWidget *parent)
	: QWidget(parent), ctrl{ c }
{
	ui.setupUi(this);

	this->populateList();

	connect(this->ui.addButton, &QPushButton::clicked, this, [this]() {
		int code = rand() % 1000;
		this->ctrl.addProduct(std::to_string(code), "Penguin food", 60);
		this->populateList();
	});
}

ShoppingBasketGUI::~ShoppingBasketGUI()
{
}

void ShoppingBasketGUI::update()
{
	this->populateList();
}

void ShoppingBasketGUI::populateList()
{
	this->ui.productsListWidget->clear();

	for (auto& p : this->ctrl.getProducts())
	{
		this->ui.productsListWidget->addItem(QString::fromStdString(p.toString()));
	}
}
