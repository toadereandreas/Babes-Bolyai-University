#include "Product.h"
#include <sstream>
#include <iomanip>

Product::Product(const std::string& c, const std::string& n, double p) : name{ n }, code{ c }, price{ p }
{
}


Product::~Product()
{
}

std::string Product::toString() const
{
	std::stringstream stream;
	stream << std::setprecision(2) << this->price;
	std::string priceToString = stream.str();
	return this->code + " - " + this->name + " - " + priceToString;
}
