#pragma once
#include <string>

class Product
{
private:
	std::string code;
	std::string name;
	double price;

public:
	Product(const std::string& c, const std::string& n, double p);
	~Product();

	std::string toString() const;
	double getPrice() const { return price; }
};

