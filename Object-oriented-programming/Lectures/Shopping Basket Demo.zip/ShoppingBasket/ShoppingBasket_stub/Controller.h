#pragma once
#include "Product.h"
#include <vector>
#include "Observer.h"

class Controller: public Subject
{
private:
	std::vector<Product> products;

public:
	Controller() {}
	void addProduct(const std::string& code, const std::string& name, double price);
	~Controller();
	std::vector<Product> getProducts();
};

