#include "ShoppingBasket_stub.h"
#include <QtWidgets/QApplication>
#include "ShoppingBasketGUI.h"
#include "ShoppingBasketWithTotal.h"

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	Controller ctrl{};
	ctrl.addProduct("111", "Icecream", 8);
	ctrl.addProduct("112", "Frozen pizza", 14.2);
	ctrl.addProduct("113", "Maltesers", 12);

	ShoppingBasketGUI b1{ ctrl };
	ShoppingBasketGUI b2{ ctrl };
	ShoppingBasketGUI b3{ ctrl };

	ShoppingBasketWithTotal b{ ctrl };

	ctrl.addObserver(&b1);
	ctrl.addObserver(&b2);
	ctrl.addObserver(&b3);
	ctrl.addObserver(&b);

	b1.show();
	b2.show();
	b3.show();
	b.show();
	return a.exec();
}
