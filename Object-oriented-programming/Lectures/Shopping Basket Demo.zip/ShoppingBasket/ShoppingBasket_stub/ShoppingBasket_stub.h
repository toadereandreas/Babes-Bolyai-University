#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_ShoppingBasket_stub.h"

class ShoppingBasket_stub : public QMainWindow
{
	Q_OBJECT

public:
	ShoppingBasket_stub(QWidget *parent = Q_NULLPTR);

private:
	Ui::ShoppingBasket_stubClass ui;
};
