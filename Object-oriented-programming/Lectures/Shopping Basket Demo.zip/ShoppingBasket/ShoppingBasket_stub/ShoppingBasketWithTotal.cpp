#include "ShoppingBasketWithTotal.h"

ShoppingBasketWithTotal::ShoppingBasketWithTotal(Controller& c,
	QWidget *parent)
	: QWidget(parent), ctrl{ c }
{
	ui.setupUi(this);

	this->populateList();

	connect(this->ui.addButton, &QPushButton::clicked, this, [this]() {
		int code = rand() % 1000;
		this->ctrl.addProduct(std::to_string(code), "Penguin food", 60);
		this->populateList();
	});
}

ShoppingBasketWithTotal::~ShoppingBasketWithTotal()
{
}

void ShoppingBasketWithTotal::update()
{
	this->populateList();

	double total = 0;
	for (auto p : this->ctrl.getProducts())
		total += p.getPrice();

	this->ui.label->setText(QString::number(total));
}

void ShoppingBasketWithTotal::populateList()
{
	this->ui.productsListWidget->clear();

	for (auto& p : this->ctrl.getProducts())
	{
		this->ui.productsListWidget->addItem(QString::fromStdString(p.toString()));
	}
}
