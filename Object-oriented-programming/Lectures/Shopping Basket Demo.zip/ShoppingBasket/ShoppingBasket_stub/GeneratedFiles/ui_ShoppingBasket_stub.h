/********************************************************************************
** Form generated from reading UI file 'ShoppingBasket_stub.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOPPINGBASKET_STUB_H
#define UI_SHOPPINGBASKET_STUB_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ShoppingBasket_stubClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *ShoppingBasket_stubClass)
    {
        if (ShoppingBasket_stubClass->objectName().isEmpty())
            ShoppingBasket_stubClass->setObjectName(QStringLiteral("ShoppingBasket_stubClass"));
        ShoppingBasket_stubClass->resize(600, 400);
        menuBar = new QMenuBar(ShoppingBasket_stubClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        ShoppingBasket_stubClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(ShoppingBasket_stubClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        ShoppingBasket_stubClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(ShoppingBasket_stubClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        ShoppingBasket_stubClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(ShoppingBasket_stubClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        ShoppingBasket_stubClass->setStatusBar(statusBar);

        retranslateUi(ShoppingBasket_stubClass);

        QMetaObject::connectSlotsByName(ShoppingBasket_stubClass);
    } // setupUi

    void retranslateUi(QMainWindow *ShoppingBasket_stubClass)
    {
        ShoppingBasket_stubClass->setWindowTitle(QApplication::translate("ShoppingBasket_stubClass", "ShoppingBasket_stub", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ShoppingBasket_stubClass: public Ui_ShoppingBasket_stubClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOPPINGBASKET_STUB_H
