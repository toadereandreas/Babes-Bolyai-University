/********************************************************************************
** Form generated from reading UI file 'ShoppingBasketGUI.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOPPINGBASKETGUI_H
#define UI_SHOPPINGBASKETGUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ShoppingBasketGUI
{
public:
    QHBoxLayout *horizontalLayout;
    QListWidget *productsListWidget;
    QPushButton *addButton;

    void setupUi(QWidget *ShoppingBasketGUI)
    {
        if (ShoppingBasketGUI->objectName().isEmpty())
            ShoppingBasketGUI->setObjectName(QStringLiteral("ShoppingBasketGUI"));
        ShoppingBasketGUI->resize(400, 300);
        horizontalLayout = new QHBoxLayout(ShoppingBasketGUI);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        productsListWidget = new QListWidget(ShoppingBasketGUI);
        productsListWidget->setObjectName(QStringLiteral("productsListWidget"));
        QFont font;
        font.setPointSize(18);
        productsListWidget->setFont(font);

        horizontalLayout->addWidget(productsListWidget);

        addButton = new QPushButton(ShoppingBasketGUI);
        addButton->setObjectName(QStringLiteral("addButton"));
        addButton->setFont(font);

        horizontalLayout->addWidget(addButton);


        retranslateUi(ShoppingBasketGUI);

        QMetaObject::connectSlotsByName(ShoppingBasketGUI);
    } // setupUi

    void retranslateUi(QWidget *ShoppingBasketGUI)
    {
        ShoppingBasketGUI->setWindowTitle(QApplication::translate("ShoppingBasketGUI", "ShoppingBasketGUI", nullptr));
        addButton->setText(QApplication::translate("ShoppingBasketGUI", "Add", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ShoppingBasketGUI: public Ui_ShoppingBasketGUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOPPINGBASKETGUI_H
