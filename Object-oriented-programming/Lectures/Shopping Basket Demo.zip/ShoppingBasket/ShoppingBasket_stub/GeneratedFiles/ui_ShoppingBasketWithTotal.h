/********************************************************************************
** Form generated from reading UI file 'ShoppingBasketWithTotal.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOPPINGBASKETWITHTOTAL_H
#define UI_SHOPPINGBASKETWITHTOTAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ShoppingBasketWithTotal
{
public:
    QHBoxLayout *horizontalLayout_2;
    QHBoxLayout *horizontalLayout;
    QListWidget *productsListWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *addButton;
    QLabel *label;

    void setupUi(QWidget *ShoppingBasketWithTotal)
    {
        if (ShoppingBasketWithTotal->objectName().isEmpty())
            ShoppingBasketWithTotal->setObjectName(QStringLiteral("ShoppingBasketWithTotal"));
        ShoppingBasketWithTotal->resize(529, 378);
        horizontalLayout_2 = new QHBoxLayout(ShoppingBasketWithTotal);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        productsListWidget = new QListWidget(ShoppingBasketWithTotal);
        productsListWidget->setObjectName(QStringLiteral("productsListWidget"));
        QFont font;
        font.setPointSize(20);
        productsListWidget->setFont(font);

        horizontalLayout->addWidget(productsListWidget);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        addButton = new QPushButton(ShoppingBasketWithTotal);
        addButton->setObjectName(QStringLiteral("addButton"));
        addButton->setFont(font);

        verticalLayout->addWidget(addButton);

        label = new QLabel(ShoppingBasketWithTotal);
        label->setObjectName(QStringLiteral("label"));
        label->setFont(font);

        verticalLayout->addWidget(label);


        horizontalLayout->addLayout(verticalLayout);


        horizontalLayout_2->addLayout(horizontalLayout);


        retranslateUi(ShoppingBasketWithTotal);

        QMetaObject::connectSlotsByName(ShoppingBasketWithTotal);
    } // setupUi

    void retranslateUi(QWidget *ShoppingBasketWithTotal)
    {
        ShoppingBasketWithTotal->setWindowTitle(QApplication::translate("ShoppingBasketWithTotal", "ShoppingBasketWithTotal", nullptr));
        addButton->setText(QApplication::translate("ShoppingBasketWithTotal", "Add", nullptr));
        label->setText(QApplication::translate("ShoppingBasketWithTotal", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ShoppingBasketWithTotal: public Ui_ShoppingBasketWithTotal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOPPINGBASKETWITHTOTAL_H
