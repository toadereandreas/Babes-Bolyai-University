#pragma once

#include <QWidget>
#include "ui_ShoppingBasketWithTotal.h"
#include "Controller.h"
#include "Observer.h"

class ShoppingBasketWithTotal : public QWidget, public Observer
{
	Q_OBJECT

private:
	Controller& ctrl;

public:
	ShoppingBasketWithTotal(Controller& c, QWidget *parent = Q_NULLPTR);
	~ShoppingBasketWithTotal();

	void update() override;

private:
	Ui::ShoppingBasketWithTotal ui;

	void populateList();
};
