#include "ShoppingBasket_stub.h"

ShoppingBasket_stub::ShoppingBasket_stub(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
