#include "Controller.h"
#include "ShoppingBasketGUI.h"

void Controller::addProduct(const std::string & code, const std::string & name, double price)
{
	Product p{ code, name, price };
	this->products.push_back(p);

	this->notify();
}

Controller::~Controller()
{
}

std::vector<Product> Controller::getProducts()
{
	return this->products;
}