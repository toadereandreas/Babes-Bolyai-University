#include "NaiveBayes.h"
#include <numeric>
#include "Utils.h"

using namespace std;

void NaiveBayes::train(const std::vector<Instance>& instances)
{
	// compute probabilities
}

std::vector<int> NaiveBayes::predict(const std::vector<Instance>& instances)
{
	std::vector<int> output{};
	// TODO
	return output;
}