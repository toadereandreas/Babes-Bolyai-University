#include "lecture10_demo_spin_slider.h"

Lecture10_demo_spin_slider::Lecture10_demo_spin_slider(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

Lecture10_demo_spin_slider::~Lecture10_demo_spin_slider()
{

}
