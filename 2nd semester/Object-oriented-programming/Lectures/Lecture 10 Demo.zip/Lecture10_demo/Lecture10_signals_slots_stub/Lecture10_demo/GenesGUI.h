#pragma once
#include <qwidget.h>
#include "Gene.h"
#include <QListWidget>
#include <QFormLayout>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>

class GenesGUI: public QWidget
{
	Q_OBJECT

public:
	GenesGUI(std::vector<Gene> genes, QWidget *parent = 0);
	~GenesGUI();

private:
	std::vector<Gene> genes;

	QListWidget* genesList;
	QLineEdit* organismEdit;
	QLineEdit* geneNameEdit;
	QTextEdit* sequenceEdit;
	QPushButton* addGeneButton;
	QPushButton* deleteGeneButton;

	void initGUI();
	int getSelectedIndex();
	
	void populateGenesList();
};

